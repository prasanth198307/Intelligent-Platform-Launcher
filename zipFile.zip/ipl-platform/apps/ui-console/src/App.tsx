import { useState } from "react";

export default function App() {
  const [text, setText] = useState("");
  const [out, setOut] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function generate() {
    setLoading(true);
    setError(null);
    setOut(null);

    try {
      const res = await fetch("/api/generate-from-message-llm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text })
      });

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }

      const data = await res.json();
      setOut(data);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ padding: 32, fontFamily: "system-ui", maxWidth: 1200, margin: "0 auto" }}>
      <h1>IPL Platform – AI Application Generator</h1>
      <p>Paste client requirement → Generate Canonical Spec (from PDF)</p>

      <textarea
        rows={8}
        style={{ width: "100%", padding: 12, fontSize: 14 }}
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Example: Build AMI billing with tariff slabs, DPDP compliance, HA DB, CC&B integration"
      />

      <div style={{ marginTop: 12 }}>
        <button
          onClick={generate}
          disabled={loading || !text.trim()}
          style={{ padding: "10px 16px", fontSize: 14 }}
        >
          {loading ? "Generating…" : "Generate"}
        </button>
      </div>

      {error && (
        <pre style={{ marginTop: 16, color: "red" }}>
          Error: {error}
        </pre>
      )}

      {out && (
        <pre style={{
          marginTop: 16,
          background: "#111",
          color: "#0f0",
          padding: 16,
          overflowX: "auto",
          fontSize: 12
        }}>
          {JSON.stringify(out, null, 2)}
        </pre>
      )}
    </div>
  );
}
