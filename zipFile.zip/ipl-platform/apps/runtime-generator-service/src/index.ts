import { generateRuntime } from "./generator.js";
export const generateFromSpec = generateRuntime;